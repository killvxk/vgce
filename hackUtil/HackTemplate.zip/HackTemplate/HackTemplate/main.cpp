#include "main.h"

BOOL APIENTRY DllMain(HMODULE, DWORD ul_reason_for_call, LPVOID)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
    /* Make any modifications to the attached program here */

    break;
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
    /* Revert all changes */
    HackUtil::Revert();
		break;
	}
	return TRUE;
}

